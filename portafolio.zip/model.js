console.log('connect');
var modal = document.querySelector('.row1');
var data = [
    
    {
        title: 'Mi primer con Proyecto JavaScript y Jquery',
        img:'../img/1/1.jpg',
        img1:'../img/1/2.jpg',
        img2:'../img/1/3.jpg',
        img3:'../img/1/4.jpg',
        content:"Fue el primer proyecto que realice implementando JavaScript y jquery. Utilizando jquery agregre varios plugis como formularios, relojes, desplegables. La mayoria del texto e imagenes estan generados desde JavaScript, solo estaba compuesto de css, pero no era responsivo.",
            
    },
    {
        title: 'Proyecto con Angular, MEAN stack',
        img:'../img/2/1.jpg',
        img1:'../img/2/2.jpg',
        img2:'../img/2/3.jpg',
        content:"Agregando cada uno de los conocimietos adquiridos en el curso, pude desarrollar una gestor de proyectos, utlizando express como framework de Nodejs, Angular como framework de JavaScript y Mongodb como base de datos, fue un proceso un poco largo.", 
 
    },
     {
        title: 'Postman para testear',
        img:'../img/3/1.jpg',
        img1:'../img/3/2.jpg',
        img2:'../img/3/3.jpg',
        content:"Se que no es un proyecto, pero aprendi a utilizarlo porque es una buena práctica antes de interactuar con una base de datos, se necesita probar cada una de las funcionalidades que se implementen del lado del controlador del Backend", 
    },
      {
        title: 'Chat con Socket.io y Nodejs',
        img:'../img/4/1.jpg',
        img1:'../img/4/2.jpg',
        img2:'../img/4/3.jpg',
        content:"Al empezar este pequeño proyecto me emocione por saber como funciona el chat en tiempo real, compartiendo la ip de mi dispositivo a un teléfono celular se pudo realizar una simulacición de chat en tiempo real.", 

    },
    //asdasd
    {
        title: 'Docker con PHP',
        img:'../img/5/1.jpg',
        img1:'../img/5/2.jpg',
        img2:'../img/5/3.jpg',
        content:"Me recomendaron una maravillosa herramienta la cual es Docker, estuve investigando sobre el tema y me propuse como meta que antes de empezar a aprender PHP debia levantar un contenedor para PHP y MYSQl, me parecio excelente para asi evitar Xamp , Wamp o alguna otra herrameinta para levantar el proyecto", 

    },
    {
        title: 'Bloc de Notas',
        img:'../img/6/1.jpg',
        img1:'../img/6/2.jpg',
        img2:'../img/6/3.jpg',
        content:"Haciendo uso del LocalStorage desarrolle un pequeño bloc de notas con varias funcionalidades como editar, eliminar, agregar, cambiar de estado de terminado a sin terminar y una función que se encargue de buscar todas las coincidencias, y con un poco de bootstrap y css para ejemplificar mi diseño previamente diseño en Photoshop", 

    },
    {
        title: 'Calculadora PHP',
        img:'../img/7/1.jpg',
        img1:'../img/7/2.jpg',
        img2:'../img/7/3.jpg',
        content:"Siempre que aprendo lo básico de un nuevo lenguaje de programación creo una Calculadora, esta no fue la excepción, cree una simple pero lo sufientemente buena de con PHP", 

    },
    {
        title: 'Maquetación totalmente responsive, creada a traves de bocetos creados en Photoshop',
        img:'../img/8/1.jpg',
        img1:'../img/8/2.jpg',
        img2:'../img/8/3.jpg',
        content:"La página ya esta subida a mi repositorio de github, esta creada desde cero, es totalmente responsive, utilizando scss, bootstrap y html",
        link: "https://davidtoj.000webhostapp.com/"
    },
    {
        title: 'Maquetación totalmente responsive',
        img:'../img/9/1.jpg',
        img1:'../img/9/2.jpg',
        img2:'../img/9/3.jpg',
        content:"Esta pagina web fue creada desde cero, utilizando html, scss, bootstrap, gulp, Nodejs. La realizacion de el mismo solamente fue para pulir mis hablidades en la mequetación web responsive", 
        link: "https://david69-js.github.io/maqueta2/"
    },
    {
        title: 'Maquetación totalmente responsive',
        img:'../img/10/1.jpg',
        img1:'../img/10/2.jpg',
        img2:'../img/10/3.jpg',
        content:"La página ya esta subida a mi repositorio de github, esta creada desde cero, es totalmente responsive, utilizando scss, bootstrap y html, adaptable a cualquier tipo de dispositivos",
        link: "https://david69-js.github.io/maqueta3/"
    },
    {
        title: 'Maquetación totalmente responsive, creada a traves de bocetos creados en Photoshop',
        img:'../img/11/1.jpg',
        img1:'../img/11/2.jpg',
        img2:'../img/11/3.jpg',
        content:"La página creada fue subida ya a mi repositorio, esta creada desde cero con bootstrap, scss, y html, y es totalmente responsive, adaptable a cualquier tipo de dispositivos", 
        link: "https://david69-js.github.io/maqueta4/"
    },
    {
        title: 'Maquetación totalmente responsive, creada a traves de bocetos creados en Photoshop',
        img:'../img/12/1.jpg',
        img1:'../img/12/2.jpg',
        img2:'../img/12/3.jpg',
        content:"Esta página web fue creada desde cero, utilizando html, scss, bootstrap. La realizacion de el mismo solamente fue para pulir mis hablidades en la maquetación web responsive, adaptable a todo tipo de dispositivo", 
        link: "https://david69-js.github.io/maqueta5/"
    },
    {
        title: 'Maquetación totalmente responsive, con angular y jquery',
        img:'../img/13/1.jpg',
        img1:'../img/13/2.jpg',
        img2:'../img/13/3.jpg',
        content:"Esta página web fue creada desde cero, utilizando scss, bootstrap, angular 10 y jquery. El proceso de mquetación esta basado en componentes, al igual que scss, para que asi cada una de las partes que la componen sean creado de manera individual", 
        link: "https://angular-nine-topaz.vercel.app/"
    },
    {
        title: 'Proyecto de php y MYSQl',
        img:'../img/14/1.jpg',
        img1:'../img/14/2.jpg',
        img2:'../img/14/3.jpg',
        img3:'../img/14/4.jpg',
        content:"Esta es una pagina creada con PHP y MYSQL y servido con Docker, se trata de un blog, en donde se pueden crear entradas, categorias, en el cual puedes crear tu propio usuario, y loguearte, la información viaja segura y también la con la contraseña cifrada", 
        link: "https://davidalv123.000webhostapp.com/index.php"
    }, 
    {
        title: 'Inioc {angular} y Laravel',
        img:'../img/15/1.jpg',
        img1:'../img/15/2.jpg',
        img2:'../img/15/3.jpg',
        img3:'../img/15/4.jpg',
        content:"Este es un crud que realice con ionic v3 el cual se maneja con angular, y pero con ciertas diferencias en cuanto a funciones, y la forma en la que se trabaja en las vistas, por otro lado Laravel que es un framework de php, el utilice como back-end y lo levante con docker. La app es un crud muy completo", 

    }, 
    {
        title: 'Prueba Quiz',
        img:'../img/16/1.jpg',
        img1:'../img/16/2.jpg',
        img2:'../img/16/3.jpg',
        img3:'../img/16/5.jpg',
        img3:'../img/16/4.jpg',
        content:"Esta estas es un prueba o test tecnico que esta basado en react js, no cree o no toque nada de backend, la api ya estaba creada, yo consumi la api con react js, valide las preguntas con datos guardados en el local storage, el diseño es totalmente resposive", 
        link: "https://github.com/david69-js/Trivia_Quiz"
    }, 
]

modal.innerHTML = '';
data.forEach((project, index)=>{

    modal.innerHTML += `<div class="col-sm-10 col-md-6">
     
    <div class="card darkborder">
         <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
            <div class="carousel-item active">
                <div class="contenedor spacing1">
                        <figure>
                            <img src="${project.img}" class="img-thumbnail"" alt="...">
                        <div class="capa">
                            <p>${project.title}</p>
                            <p>${project.content}</p>
                            ${project.link
                            ? `<a href="${project.link}" target="_blank"><button  class="btn btn-dark">Ver página </button></a>`
                            : ``
                            }
                        </div>
                        </figure> 
                    </div> 
                </div>
    
                <div class="carousel-item">
                    <div class="contenedor spacing1">
                        <figure>
                            <img src="${project.img1}" class="img-thumbnail"" alt="...">
                        <div class="capa">
                            <p>${project.title}</p>
                            <p>${project.content}</p>
                            ${project.link
                            ? `<a href="${project.link}" target="_blank"><button  class="btn btn-dark">Ver página </button></a>`
                            : ``
                            }
                        </div>
                        </figure> 
                    </div> 
                </div>
        
                ${project.img3 
                ?`
                <div class="carousel-item">
                    <div class="contenedor spacing1">
                        <figure>
                            <img src="${project.img3}" class="img-thumbnail"" alt="...">
                        <div class="capa">
                            <p>${project.title}</p>
                            <p>${project.content}</p>
                            ${project.link
                            ? `<a href="${project.link}" target="_blank"><button  class="btn btn-dark">Ver página </button></a>`
                            : ``
                            }
                        </div>
                        </figure> 
                    </div> 
                </div>     
                <div class="carousel-item">
                <div class="contenedor spacing1">
                    <figure>
                        <img src="${project.img2}" class="img-thumbnail"" alt="...">
                    <div class="capa">
                        <p>${project.title}</p>
                        <p>${project.content}</p>
                        ${project.link
                            ? `<a href="${project.link}" target="_blank"><button  class="btn btn-dark">Ver página </button></a>`
                            : ``
                            }
                    </div>
                    </figure> 
                </div> 
            </div>           
                `
                :`
                <div class="carousel-item">
                    <div class="contenedor spacing1">
                        <figure>
                            <img src="${project.img2}" class="img-thumbnail"" alt="...">
                        <div class="capa">
                            <p>${project.title}</p>
                            <p>${project.content}</p>
                            ${project.link
                            ? `<a href="${project.link}" target="_blank"><button  class="btn btn-dark">Ver página </button></a>`
                            : ``
                            }
                        </div>
                        </figure> 
                    </div> 
                </div>                
                `  }


                ${project.img4 
                    ?`
                    <div class="carousel-item">
                        <div class="contenedor spacing1">
                            <figure>
                                <img src="${project.img4}" class="img-thumbnail"" alt="...">
                            <div class="capa">
                                <p>${project.title}</p>
                                <p>${project.content}</p>
                                ${project.link
                            ? `<a href="${project.link}" target="_blank"><button  class="btn btn-dark">Ver página </button></a>`
                            : ``
                            }
                            </div>
                            </figure> 
                        </div> 
                    </div>     
                    <div class="carousel-item">
                    <div class="contenedor spacing1">
                        <figure>
                            <img src="${project.img3}" class="img-thumbnail"" alt="...">
                        <div class="capa">
                            <p>${project.title}</p>
                            <p>${project.content}</p>
                            ${project.link
                            ? `<a href="${project.link}" target="_blank"><button  class="btn btn-dark">Ver página </button></a>`
                            : ``
                            }
                        </div>
                        </figure> 
                    </div> 
                </div>           
                    `
                    :`
                    <div class="carousel-item">
                        <div class="contenedor spacing1">
                            <figure>
                                <img src="${project.img2}" class="img-thumbnail"" alt="...">
                            <div class="capa">
                                <p>${project.title}</p>
                                <p>${project.content}</p>
                                ${project.link
                            ? `<a href="${project.link}" target="_blank"><button  class="btn btn-dark">Ver página </button></a>`
                            : ``
                            }
                            </div>
                            </figure> 
                        </div> 
                    </div>                
                    `  }


            </div>
        </div>
    </div>
</div>
        `
        ;
    
});



